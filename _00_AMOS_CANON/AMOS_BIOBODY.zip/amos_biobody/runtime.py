
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, Any, List

from .body.state import BodyState
from .body.senses import SensorySystem, SensoryInput
from .body.motor import MotorSystem, MotorCommand
from .body.endocrine import EndocrineSystem
from .body.immune import ImmuneSystem
from .body.memory import MemorySystem


@dataclass
class BioBody:
    state: BodyState
    senses: SensorySystem
    motor: MotorSystem
    endocrine: EndocrineSystem
    immune: ImmuneSystem
    memory: MemorySystem

    def step(self, external_stimuli: Dict[str, Any]) -> Dict[str, Any]:
        # 1) Sense the world
        raw_in = SensoryInput(timestamp=time.time(), channels=external_stimuli)
        perceived = self.senses.process(raw_in, self.state)

        # 2) Update internal state from endocrine + immune
        self.endocrine.update(self.state, perceived)
        self.immune.monitor(self.state, perceived)

        # 3) Decide an action (very simple demo policy)
        intent = self._simple_policy(perceived)

        # 4) Convert into motor command
        command = self.motor.plan(intent, self.state)

        # 5) Execute motor action
        effect = self.motor.execute(command, self.state)

        # 6) Update memory
        self.memory.record(self.state, perceived, intent, command, effect)

        # Return a structured tick record
        return {
            "perceived": perceived.summary(),
            "intent": intent,
            "command": command.summary(),
            "effect": effect,
            "state": self.state.summary(),
        }

    def _simple_policy(self, perceived: Dict[str, Any]) -> Dict[str, Any]:
        # Extremely simple placeholder "reasoning"
        mood = perceived.get("mood", "neutral")
        task = perceived.get("task", "idle")

        if task == "write_code":
            focus = 0.9
        elif task == "design":
            focus = 0.7
        else:
            focus = 0.3

        if mood == "stressed":
            intensity = 0.4
        elif mood == "calm":
            intensity = 0.9
        else:
            intensity = 0.6

        return {
            "goal": task,
            "focus": focus,
            "intensity": intensity,
        }


def build_default_body() -> BioBody:
    state = BodyState()
    senses = SensorySystem()
    motor = MotorSystem()
    endocrine = EndocrineSystem()
    immune = ImmuneSystem()
    memory = MemorySystem()
    return BioBody(
        state=state,
        senses=senses,
        motor=motor,
        endocrine=endocrine,
        immune=immune,
        memory=memory,
    )


def run() -> None:
    body = build_default_body()
    print("=== AMOS BIOLOGICAL BODY DEMO ===")
    print("This is a small, self-contained demo body with:")
    print(" - state, senses, motor, endocrine, immune, memory")
    print(" - a simple policy loop")
    print()

    demo_stimuli = [
        {"task": "idle", "mood": "neutral"},
        {"task": "design", "mood": "curious"},
        {"task": "write_code", "mood": "calm"},
        {"task": "write_code", "mood": "stressed"},
    ]

    for i, stim in enumerate(demo_stimuli, start=1):
        print(f"--- TICK {i} ---")
        record = body.step(stim)
        print("Perceived:", record["perceived"])
        print("Intent:", record["intent"])
        print("Command:", record["command"])
        print("Effect:", record["effect"])
        print("State:", record["state"])
        print()
        time.sleep(0.1)


if __name__ == "__main__":
    run()
