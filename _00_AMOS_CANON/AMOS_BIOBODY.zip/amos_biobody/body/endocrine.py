
from __future__ import annotations

from .state import BodyState


class EndocrineSystem:
    def update(self, state: BodyState, perceived) -> None:
        mood = perceived.get("mood", "neutral")
        if mood == "stressed":
            state.stress = min(1.0, state.stress + 0.1)
        elif mood == "calm":
            state.stress = max(0.0, state.stress - 0.05)
        state.energy = max(0.0, min(1.0, state.energy + 0.01))
