
from __future__ import annotations

from .state import BodyState


class ImmuneSystem:
    def monitor(self, state: BodyState, perceived) -> None:
        if state.stress > 0.8 or state.energy < 0.2:
            state.health = max(0.0, state.health - 0.02)
        else:
            state.health = min(1.0, state.health + 0.005)
