
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from .state import BodyState


@dataclass
class MotorCommand:
    system: str
    action: str
    params: Dict[str, Any]

    def summary(self) -> Dict[str, Any]:
        return {
            "system": self.system,
            "action": self.action,
            "params": self.params,
        }


class MotorSystem:
    def plan(self, intent: Dict[str, Any], state: BodyState) -> MotorCommand:
        goal = intent.get("goal", "idle")
        focus = intent.get("focus", 0.5)
        intensity = intent.get("intensity", 0.5)

        if goal == "write_code":
            system = "cortex"
            action = "generate_code_block"
        elif goal == "design":
            system = "cortex"
            action = "generate_design_spec"
        else:
            system = "default"
            action = "idle"

        return MotorCommand(
            system=system,
            action=action,
            params={
                "focus": focus,
                "intensity": intensity,
                "goal": goal,
            },
        )

    def execute(self, cmd: MotorCommand, state: BodyState) -> Dict[str, Any]:
        goal = cmd.params.get("goal", "idle")
        intensity = cmd.params.get("intensity", 0.5)

        state.energy = max(0.0, state.energy - 0.1 * intensity)
        state.stress = max(0.0, min(1.0, state.stress + 0.05 * (intensity - 0.5)))
        state.focus = max(0.0, min(1.0, cmd.params.get("focus", state.focus)))

        if goal == "write_code":
            produced = "code_stub"
        elif goal == "design":
            produced = "design_outline"
        else:
            produced = "noop"

        return {
            "produced": produced,
            "goal": goal,
            "intensity": intensity,
        }
