
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any

from .state import BodyState


@dataclass
class SensoryInput:
    timestamp: float
    channels: Dict[str, Any]


class SensorySystem:
    def process(self, raw: SensoryInput, state: BodyState) -> Dict[str, Any]:
        mood = raw.channels.get("mood", state.mood)
        state.mood = mood
        perceived = {
            "time": raw.timestamp,
            "task": raw.channels.get("task", "idle"),
            "mood": mood,
        }
        return perceived

    # Convenience for runtime
    def summary(self, perceived: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "task": perceived.get("task"),
            "mood": perceived.get("mood"),
        }

# Allow Body.step to call perceived.summary()
SensoryInput.summary = lambda self: self.channels  # type: ignore
