
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass
class BodyState:
    energy: float = 0.8           # 0..1
    stress: float = 0.2           # 0..1
    focus: float = 0.5            # 0..1
    health: float = 1.0           # 0..1
    mood: str = "neutral"
    context: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> Dict[str, Any]:
        return {
            "energy": round(self.energy, 3),
            "stress": round(self.stress, 3),
            "focus": round(self.focus, 3),
            "health": round(self.health, 3),
            "mood": self.mood,
        }
