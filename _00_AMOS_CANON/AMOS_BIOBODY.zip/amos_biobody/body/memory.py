
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from .state import BodyState


@dataclass
class MemoryEvent:
    perceived: Dict[str, Any]
    intent: Dict[str, Any]
    command: Dict[str, Any]
    effect: Dict[str, Any]
    snapshot: Dict[str, Any]


class MemorySystem:
    def __init__(self) -> None:
        self.events: List[MemoryEvent] = []

    def record(
        self,
        state: BodyState,
        perceived: Dict[str, Any],
        intent: Dict[str, Any],
        command,
        effect: Dict[str, Any],
    ) -> None:
        event = MemoryEvent(
            perceived=perceived,
            intent=intent,
            command=command.summary(),
            effect=effect,
            snapshot=state.summary(),
        )
        self.events.append(event)

    def last(self, n: int = 5) -> List[Dict[str, Any]]:
        return [e.__dict__ for e in self.events[-n:]]
