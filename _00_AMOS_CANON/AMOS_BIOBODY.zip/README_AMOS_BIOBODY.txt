
AMOS BIOLOGICAL BODY DEMO
=========================

This zip contains a small, self-contained Python package that models
a very simplified "biological body" with:

- BodyState (energy, stress, focus, health, mood)
- SensorySystem
- MotorSystem
- EndocrineSystem
- ImmuneSystem
- MemorySystem
- A runtime loop that wires them together

How to use (minimal):

1) Unzip this archive somewhere, for example into:
   /Users/you/AMOS-BIOBODY

2) Create and activate a virtual environment (optional but recommended):

   cd /Users/you/AMOS-BIOBODY
   python3 -m venv .venv
   source .venv/bin/activate

3) Run the demo:

   python -m amos_biobody.runtime

or

   python -c "from amos_biobody import run; run()"

4) Integration with your AMOS-SYSTEM:

   - Copy the 'amos_biobody' folder into your AMOS-SYSTEM repo, or
   - Install this as a local package inside your AMOS-SYSTEM venv:

     pip install -e .

   Then you can import and drive it from your orchestrator:

     from amos_biobody import run as run_biobody
     run_biobody()

This is deliberately clean, minimal, and deterministic. It is meant as
a "biological body core" you can extend over time (more detailed
senses, more sophisticated policy, richer state, etc.) without
touching your lower-level AMOS motor / workers wiring.
